import java.util.Scanner;

public class Employee {

	public static void main(String[] args) {
		
		Scanner sc = new Scanner(System.in);
		System.out.println("Select the Options between Admin or User");
		int option = sc.nextInt();
		if(option == 1) {
			
		}

	}

}

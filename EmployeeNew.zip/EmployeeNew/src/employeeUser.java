
 
public class employeeUser extends Empdata{
	
	public employeeUser(int number, String ename, String accNo, String bu) {
		super(number, ename, accNo, bu);
		
	}
	
public boolean login(String uname,String password) {
	if(username == )&&(password == ){
		return true;
	}
	else {
	return false;
	}
}

 
}
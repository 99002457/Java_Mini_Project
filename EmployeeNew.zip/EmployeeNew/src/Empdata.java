import java.awt.Panel;

import javax.swing.*;

public class Empdata {
	private int psNumber;
	private String name;
	private String accountNo;
	private String buName;

	public Empdata(int number, String ename, String accNo,String bu)
	{
//		JFrame frame=new JFrame();
//		JPanel panle=new JPanel();
//		frame.setContentPane(panle);
//		frame.setLayout(null);
//		
//		JLabel  label=new JLabel();
//		label.setText("Hello welcome to the Emp");
//		panle.add(label);
//		frame.setVisible(true);
		this.psNumber = number;
		this.name=ename;
		this.accountNo=accNo;
		this.buName=bu;
	}
	
	public static void main(String[] args) {
		Empdata emp= new Empdata(99002457,"chethan","9100631334","ICP");
		
	}
	
	public String getAccountNo() {
		return accountNo;
	}
	 public String getBuName() {
		return buName;
	}
	 public int getPsNumber() {
		return psNumber;
	}
	 public String getName() {
		return name;
	}
	 public void setAccountNo(String accountNo) {
		this.accountNo = accountNo;
	}
	 public void setBuName(String buName) {
		this.buName = buName;
	}
	 public void setName(String name) {
		this.name = name;
	}
	 public void setPsNumber(int psNumber) {
		this.psNumber = psNumber;
	}
	 
	 @Override
	public String toString() {
		// TODO Auto-generated method stub
		return this.psNumber+" "+this.name+" "+this.accountNo+" "+this.buName;
	}
	 public void createEmp() { 
		 
		  
		  
	 }
	 public void updateEmp() { 
		   
	 }
	 public void retriveEmp() { 
		 
		  
		  
	 }public void deleteEmp() { 
		 
		  
		  
	 }
	 

}
